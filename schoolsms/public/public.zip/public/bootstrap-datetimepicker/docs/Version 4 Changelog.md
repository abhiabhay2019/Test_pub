<meta http-equiv="refresh" content="1; url=/Changelog/"/>
<meta http-equiv="refresh" content="0; url=/Changelog/"/>
<link rel="canonical" href="/Changelog/">

 <p>The page has moved to: 
   <a href="/Changelog/">this page</a></p>